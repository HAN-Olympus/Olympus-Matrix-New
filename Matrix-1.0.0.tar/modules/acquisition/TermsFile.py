"""
@name TermsFile
@author Tom Linssen
@module Matrix
@version 1.0.0
"""

from Olympus.modules.acquisition.AcquisitionModule import AcquisitionModule

from Olympus.lib.Article import Article
from Olympus.lib.StringContainer import StringContainer
from Olympus.lib.Collection import Collection
from Olympus.lib.controls.File import File

import re

class TermsFile(AcquisitionModule):
	def __init__(self):
		pass
	
	def specifyControls(self):
		controls = {
			"fileOne" : File("fileOne", label="File one"),
			"fileTwo" : File("fileTwo", label="File two")
		}
		return controls
	
	def specifyInput(self):
		return None
		
	def specifyOutput(self):
		termsCollection = Collection(StringContainer)
		
		output = {
			"result":[termsCollection]
		}
		return output
		
	def start(self, **kwargs):
		splitWords = re.compile("\s+")
		primaryFile = splitWords.split(kwargs.get("fileOne", ""))
		secondaryFile = splitWords.split(kwargs.get("fileTwo", ""))
		
		return [primaryFile,secondaryFile]